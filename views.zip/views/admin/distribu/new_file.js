json={
	start_time:'1212-10-10',//启用时间
	oil_id:1,//生效油站
	start_money:100,
	oils_id:'1,2,3,4,5,6,7,8,9',
	
	
	
}
